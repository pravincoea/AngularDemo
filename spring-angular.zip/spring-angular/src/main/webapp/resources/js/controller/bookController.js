function bookController($scope, BookService) {
	var self = this;
	$scope.book = {};
	self.books = [];
	$scope.action = 'add';
	$scope.message = '';

	

	getAllBooks();

	function getAllBooks() {
		console.log("####bookController:getAllBooks()#########");
		BookService.getAllBook().then(function(d) {
			self.books = d;
		}, function(errResponse) {
			console.error(errResponse);
		});

	}

	$scope.add = function() {
		console.log("####bookController:add()#########");
		var json = angular.toJson($scope.book)
		BookService.addBook($scope.book).then(function(d) {
			$scope.message = 'Book Added Successfully';
			getAllBooks();
			$scope.clear();
		}, function(errResponse) {
			console.error(errResponse);
		});
	}

	$scope.update = function() {
		console.log("####bookController:update()#########");
		BookService.updateBook($scope.book).then(function(d) {
			$scope.message = 'Book Updated Successfully';
			getAllBooks();
		}, function(errResponse) {
			console.error(errResponse);
		});
	}
	
	$scope.clear = function() {
		console.log("####bookController:clear()#########");
		$scope.book = {};
		$scope.action = 'add';
		
	}
	
	$scope.edit = function(book) {
		console.log("####bookController:edit()#########");
		$scope.book = book;
		$scope.action = 'update';
	}

	$scope.deleteBook = function(book){
		console.log("####bookController:deleteBook()#########");
		BookService.deleteBook(book).then(function(d) {
			$scope.message = 'Book Delted Successfully';
			getAllBooks();
		}, function(errResponse) {
			console.error(errResponse);
		});
	}
}

var app = angular.module('bookApp', [ 'MyOwnService' ]);
app.controller('bookController', bookController);