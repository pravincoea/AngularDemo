var validationHandler = angular.module('MyOwnService', []);
validationHandler.factory('BookService', function($http, $q) {
	var REST_SERVICE_URI = 'http://localhost:8080/angular/';
	var factory = {
		getAllBook : getAllBook,
		addBook : addBook,
		updateBook : updateBook,
		deleteBook : deleteBook
	};
	return factory;

	function getAllBook() {
		console.log("####service:getAllBook()#########");
		var deferred = $q.defer();

		$http.get(REST_SERVICE_URI + 'rest/getAllBook').then(
				function(response) {

					deferred.resolve(response.data);
				}, function(errResponse) {
					console.error(errResponse);
					deferred.reject(errResponse);
				});

		return deferred.promise;
	}

	function addBook(book) {
		console.log("####service:addBook()#########");
		var deferred = $q.defer();

		$http.post(REST_SERVICE_URI + 'rest/addBook', book).then(
				function(response) {
					deferred.resolve(response.data);
				}, function(errResponse) {
					console.error(errResponse);
					deferred.reject(errResponse);
				});

		return deferred.promise;
	}

	function updateBook(book) {
		console.log("####service:updateBook()#########");
		var deferred = $q.defer();

		$http.post(REST_SERVICE_URI + 'rest/updateBook', book).then(
				function(response) {

					deferred.resolve(response.data);
				}, function(errResponse) {
					console.error(errResponse);
					deferred.reject(errResponse);
				});

		return deferred.promise;
	}

	function deleteBook(book) {
		console.log("####service:deleteBook()#########");
		var deferred = $q.defer();
		$http.post(REST_SERVICE_URI + 'rest/deleteBook', book).then(
				function(response) {

					deferred.resolve(response.data);
				}, function(errResponse) {
					console.error(errResponse);
					deferred.reject(errResponse);
				});

		return deferred.promise;
	}
});