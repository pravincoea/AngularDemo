# spring-mvc-crud-example
A complete example of CRUD operations. 
<br/>
Some key points of this example
 <ul>
  <li>DAO Pattern</li>
  <li>Service Layer</li>
  <li>Spring 4</li>
  <li>Fully Annotation Based</li>
  <li>Hibernate & Spring Integration</li>
  <li>MySQL</li>
  <li>Maven Based</li>
  <li>Added Sample JUNIT</li>
  <li>Added Properties file for MySQL credentials</li>
</ul> 
